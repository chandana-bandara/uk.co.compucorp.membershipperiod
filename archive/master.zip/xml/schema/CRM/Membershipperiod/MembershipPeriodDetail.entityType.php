<?php
// This file declares a new entity type. For more details, see "hook_civicrm_entityTypes" at:
// http://wiki.civicrm.org/confluence/display/CRMDOC/Hook+Reference
return array (
  0 => 
  array (
    'name' => 'MembershipPeriodDetail',
    'class' => 'CRM_Membershipperiod_DAO_MembershipPeriodDetail',
    'table' => 'civicrm_membershipperioddetail',
  ),
);
