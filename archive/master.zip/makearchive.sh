#!/bin/bash

git archive -o archive/master.zip HEAD
