<?php

class CRM_Membershipperiod_BAO_MembershipPeriodMembershipDuration {
	const YEAR = "year";
	const MONTH = "month";
	const DAY = "day";
	const LIFETIME = "lifetime";
}