<?php

class CRM_Membershipperiod_BAO_MembershipPeriodMembershipPeriodType{
	const ROLLING = "rolling";
	const FIXED = "fixed";
}